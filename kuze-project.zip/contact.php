<?php
// contact.php - kuze.ug Contact Form Handler
// Place this file in the root directory

// Prevent direct access
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: contact.html');
    exit;
}

// Configuration
$to_email = "info@kuze.ug";
$cc_email = "support@kuze.ug";
$from_domain = "kuze.ug";
$upload_max_files = 2;
$max_file_size = 5 * 1024 * 1024; // 5MB
$allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

// Initialize response
$response = ['success' => false, 'message' => ''];

// Sanitize input
$name = trim($_POST['name'] ?? '');
$business = trim($_POST['business'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone_code = trim($_POST['phone_code'] ?? '+256');
$phone = trim($_POST['phone'] ?? '');
$whatsapp_code = trim($_POST['whatsapp_code'] ?? '+256');
$whatsapp = trim($_POST['whatsapp'] ?? '');
$location = trim($_POST['location'] ?? '');
$reason = $_POST['reason'] ?? '';
$message = trim($_POST['message'] ?? '');

// Validation
$errors = [];

if (empty($name)) $errors[] = "Full name is required.";
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Valid email is required.";
if (empty($phone)) $errors[] = "Phone number is required.";
if (empty($location)) $errors[] = "Location is required.";
if (empty($reason)) $errors[] = "Please select a reason.";
if (empty($message)) $errors[] = "Message cannot be empty.";

// Process uploaded files
$uploaded_files = [];
if (!empty($_FILES['attachments']['name'][0])) {
    $file_count = count($_FILES['attachments']['name']);
    $process_count = min($file_count, 2);
    
    for ($i = 0; $i < $process_count; $i++) {
        if ($_FILES['attachments']['error'][$i] === UPLOAD_ERR_OK) {
            $file_tmp = $_FILES['attachments']['tmp_name'][$i];
            $file_name = $_FILES['attachments']['name'][$i];
            $file_size = $_FILES['attachments']['size'][$i];
            
            if ($file_size > $max_file_size) {
                $errors[] = "File '{$file_name}' exceeds 5MB limit.";
                continue;
            }
            
            $ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            if (!in_array($ext, $allowed_extensions)) {
                $errors[] = "File '{$file_name}' is not an allowed image type.";
                continue;
            }
            
            $safe_name = uniqid('kuze_', true) . '.' . $ext;
            $upload_dir = 'uploads/contact/';
            
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $upload_path = $upload_dir . $safe_name;
            
            if (move_uploaded_file($file_tmp, $upload_path)) {
                $uploaded_files[] = [
                    'original' => $file_name,
                    'saved_as' => $safe_name,
                    'path' => $upload_path
                ];
            } else {
                $errors[] = "Failed to upload file: {$file_name}";
            }
        }
    }
    
    if ($file_count > 2) {
        $errors[] = "Only the first 2 images were uploaded. Maximum 2 files allowed.";
    }
}

// Return errors if any
if (!empty($errors)) {
    $error_string = implode("\\n", $errors);
    header("Location: contact.html?error=" . urlencode($error_string));
    exit;
}

// Prepare email
$full_phone = $phone_code . ' ' . $phone;
$full_whatsapp = !empty($whatsapp) ? $whatsapp_code . ' ' . $whatsapp : 'Not provided';

$subject = "kuze.ug Contact: " . ucfirst($reason) . " - " . $name;

// HTML Email
$email_body = "
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: -apple-system, sans-serif; line-height: 1.6; color: #202124; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #dadce0; border-radius: 10px; }
        h2 { color: #dc2626; margin-bottom: 20px; }
        .field { margin-bottom: 15px; }
        .label { font-weight: 600; color: #5f6368; }
        .value { background: #f8f9fa; padding: 8px 12px; border-radius: 6px; margin-top: 4px; }
        .footer { margin-top: 30px; font-size: 0.85rem; color: #5f6368; border-top: 1px solid #dadce0; padding-top: 15px; }
    </style>
</head>
<body>
    <div class='container'>
        <h2>New Contact Form - kuze.ug</h2>
        
        <div class='field'>
            <span class='label'>Reason:</span>
            <div class='value'>" . ucfirst(str_replace('_', ' ', $reason)) . "</div>
        </div>
        
        <div class='field'>
            <span class='label'>Name:</span>
            <div class='value'>" . htmlspecialchars($name) . "</div>
        </div>";

if (!empty($business)) {
    $email_body .= "
        <div class='field'>
            <span class='label'>Business:</span>
            <div class='value'>" . htmlspecialchars($business) . "</div>
        </div>";
}

$email_body .= "
        <div class='field'>
            <span class='label'>Email:</span>
            <div class='value'><a href='mailto:" . htmlspecialchars($email) . "'>" . htmlspecialchars($email) . "</a></div>
        </div>
        
        <div class='field'>
            <span class='label'>Phone:</span>
            <div class='value'><a href='tel:" . htmlspecialchars($full_phone) . "'>" . htmlspecialchars($full_phone) . "</a></div>
        </div>";

if (!empty($whatsapp)) {
    $whatsapp_link = str_replace(' ', '', $full_whatsapp);
    $email_body .= "
        <div class='field'>
            <span class='label'>WhatsApp:</span>
            <div class='value'><a href='https://wa.me/" . htmlspecialchars($whatsapp_link) . "'>" . htmlspecialchars($full_whatsapp) . "</a></div>
        </div>";
}

$email_body .= "
        <div class='field'>
            <span class='label'>Location:</span>
            <div class='value'>" . htmlspecialchars($location) . "</div>
        </div>
        
        <div class='field'>
            <span class='label'>Message:</span>
            <div class='value' style='white-space: pre-line;'>" . nl2br(htmlspecialchars($message)) . "</div>
        </div>";

if (!empty($uploaded_files)) {
    $email_body .= "
        <div class='field'>
            <span class='label'>Attachments (" . count($uploaded_files) . "):</span>
            <div class='value'>";
    foreach ($uploaded_files as $file) {
        $email_body .= "• " . htmlspecialchars($file['original']) . " (saved as " . htmlspecialchars($file['saved_as']) . ")<br>";
    }
    $email_body .= "</div></div>";
}

$email_body .= "
        <div class='footer'>
            <p>IP: " . $_SERVER['REMOTE_ADDR'] . "<br>
            Date: " . date('Y-m-d H:i:s') . " (EAT)</p>
        </div>
    </div>
</body>
</html>";

// Headers
$headers = "From: kuze.ug Contact <noreply@" . $from_domain . ">\r\n";
$headers .= "Reply-To: " . $email . "\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";

// Send email
$mail_sent = mail($to_email, $subject, $email_body, $headers);

// Log submission
$log_entry = date('Y-m-d H:i:s') . " | " . $name . " | " . $email . " | " . $reason . " | " . $location . " | Files: " . count($uploaded_files) . "\n";
file_put_contents('contact_submissions.log', $log_entry, FILE_APPEND | LOCK_EX);

// Redirect
if ($mail_sent) {
    header("Location: contact.html?success=1");
} else {
    header("Location: contact.html?error=" . urlencode("Failed to send. Please try again."));
}
exit;
?>