// Map functionality
console.log('Map.js loaded');