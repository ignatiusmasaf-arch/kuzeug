// Form validation
console.log('Validation.js loaded');