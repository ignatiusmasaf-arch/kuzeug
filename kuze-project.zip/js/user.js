// User account functionality
console.log('User.js loaded');