// Business listing functionality
console.log('Business.js loaded');