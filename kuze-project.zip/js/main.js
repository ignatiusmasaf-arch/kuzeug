// ==================== DATA ====================
const categories = [
    { icon: "fa-house-chimney", name: "Household & Home Services", slug: "household-services" },
    { icon: "fa-hotel", name: "Accommodation & Hospitality", slug: "accommodation" },
    { icon: "fa-utensils", name: "Food & Dining", slug: "food-dining" },
    { icon: "fa-hospital", name: "Health & Medical", slug: "health-medical" },
    { icon: "fa-bag-shopping", name: "Shopping & Retail", slug: "shopping-retail" },
    { icon: "fa-spa", name: "Beauty & Personal Care", slug: "beauty-personal-care" },
    { icon: "fa-umbrella-beach", name: "Entertainment & Tourism", slug: "entertainment-tourism" },
    { icon: "fa-building-columns", name: "Finance & Banking", slug: "finance-banking" },
    { icon: "fa-graduation-cap", name: "Education & Training", slug: "education-training" },
    { icon: "fa-truck", name: "Transport & Logistics", slug: "transport-logistics" },
    { icon: "fa-hard-hat", name: "Construction & Real Estate", slug: "construction-real-estate" },
    { icon: "fa-tractor", name: "Agriculture & Agribusiness", slug: "agriculture" },
    { icon: "fa-industry", name: "Manufacturing & Industry", slug: "manufacturing" },
    { icon: "fa-microchip", name: "Technology & IT", slug: "technology-it" },
    { icon: "fa-scale-balanced", name: "Professional Services", slug: "professional-services" },
    { icon: "fa-car", name: "Automotive", slug: "automotive" },
    { icon: "fa-tower-broadcast", name: "Media & Communication", slug: "media-communication" },
    { icon: "fa-landmark", name: "Government & NGOs", slug: "government-ngos" },
    { icon: "fa-shield", name: "Security Services", slug: "security-services" },
    { icon: "fa-gavel", name: "Legal Services", slug: "legal-services" }
];

const featuredBusinesses = [
    { name: "Jinja Adventure Tours", category: "Entertainment", location: "Jinja", rating: 4.8, image: "https://picsum.photos/seed/jinja1/400/300", slug: "jinja-adventure-tours" },
    { name: "Kampala City Hardware", category: "Construction", location: "Kampala", rating: 4.5, image: "https://picsum.photos/seed/hardware1/400/300", slug: "kampala-city-hardware" },
    { name: "Victoria Dental Clinic", category: "Health", location: "Kampala", rating: 4.9, image: "https://picsum.photos/seed/dental1/400/300", slug: "victoria-dental-clinic" },
    { name: "Mbarara Fresh Produce", category: "Agriculture", location: "Mbarara", rating: 4.7, image: "https://picsum.photos/seed/farm1/400/300", slug: "mbarara-fresh-produce" }
];

const heroAds = [
    { name: "Kampala Business Expo 2026", image: "https://picsum.photos/seed/expo1/1600/600" },
    { name: "Uganda Manufacturers Association", image: "https://picsum.photos/seed/uma1/1600/600" },
    { name: "Jinja Tourism Week", image: "https://picsum.photos/seed/jinjatour/1600/600" },
    { name: "Kampala City Festival", image: "https://picsum.photos/seed/festival/1600/600" }
];

const regions = [
    { name: "Central", districts: ["Kampala", "Wakiso", "Mukono", "Masaka", "Entebbe"] },
    { name: "Eastern", districts: ["Jinja", "Mbale", "Tororo", "Soroti", "Busia"] },
    { name: "Northern", districts: ["Gulu", "Lira", "Arua", "Kitgum", "Kotido"] },
    { name: "Western", districts: ["Mbarara", "Kasese", "Fort Portal", "Kabale", "Bushenyi"] }
];

// NEW: Ad Data for Sidebar and Mobile Carousel
const sidebarAds = [
    { type: "event", title: "Kampala Business Expo", date: "March 15-17, 2026", desc: "Uganda's largest business networking event", link: "#" },
    { type: "event", title: "Jinja Tourism Week", date: "April 5-12, 2026", desc: "Explore the source of the Nile", link: "#" },
    { type: "event", title: "Digital Marketing Workshop", date: "Every Saturday", desc: "Free online training for businesses", link: "#" },
    { type: "sponsored", title: "Stanbic Bank Uganda", desc: "Business loans at 12% p.a.", link: "#" },
    { type: "sponsored", title: "MTN Business", desc: "Internet solutions for your business", link: "#" }
];

// ==================== COMPONENT LOADER ====================
async function loadComponent(elementId, componentPath) {
    try {
        const path = window.location.pathname;
        const isInPagesFolder = path.includes('/pages/');
        
        let finalPath = componentPath;
        if (isInPagesFolder) {
            finalPath = '../' + componentPath;
        }
        
        console.log(`Loading ${elementId} from:`, finalPath);
        
        const response = await fetch(finalPath);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        const html = await response.text();
        
        const element = document.getElementById(elementId);
        if (element) {
            element.innerHTML = html;
            console.log(`✅ Loaded: ${elementId}`);
        }
    } catch (error) {
        console.error(`❌ Error loading ${componentPath}:`, error);
        const element = document.getElementById(elementId);
        if (element) {
            element.innerHTML = `<div style="background:#fee; color:#c00; padding:10px; text-align:center; font-size:12px;">
                Failed to load component. Please use the start-server.bat file to run a local server.
            </div>`;
        }
    }
}

// ==================== PAGE INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', async function() {
    console.log('DOM loaded, loading components...');
    
    await loadComponent('header-placeholder', 'components/header.html');
    await loadComponent('mobile-menu-placeholder', 'components/mobile-menu.html');
    await loadComponent('footer-placeholder', 'components/footer.html');
    
    setTimeout(() => {
        initializePage();
        initializeMoveToTop();
        initializeMobileAdCarousel();
    }, 200);
});

function initializePage() {
    loadCategories();
    initializeHomePage();
    attachEventListeners();
}

function loadCategories() {
    const desktopList = document.getElementById('desktop-category-list');
    if (desktopList) {
        desktopList.innerHTML = categories.map(cat => 
            `<a href="../pages/regions/central.html" class="block px-6 py-2.5 hover:bg-red-50 text-sm border-b border-gray-50 last:border-0">
                <i class="fa-solid ${cat.icon} w-5 text-red-600 mr-2"></i>${cat.name}
            </a>`
        ).join('');
    }

    const mobileList = document.getElementById('mobile-category-list');
    if (mobileList) {
        mobileList.innerHTML = categories.map(cat => 
            `<a href="../pages/regions/central.html" class="block py-4 border-b border-gray-100 last:border-0 text-sm pl-8 hover:bg-white hover:text-red-600">
                <i class="fa-solid ${cat.icon} w-5 text-red-600 mr-2"></i>${cat.name}
            </a>`
        ).join('');
    }
}

function initializeHomePage() {
    // Hero slider
    const adWrapper = document.getElementById('ad-wrapper');
    if (adWrapper) {
        adWrapper.innerHTML = heroAds.map(ad => `
            <div class="swiper-slide relative">
                <img src="../pages/regions/central.html" class="w-full h-full object-cover">
                <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent flex flex-col justify-end p-10 md:p-20 text-white">
                    <h2 class="text-4xl md:text-6xl font-black drop-shadow-2xl">${ad.name}</h2>
                </div>
            </div>
        `).join('');
        
        if (typeof Swiper !== 'undefined') {
            new Swiper(".mySwiper", { 
                loop: true, 
                autoplay: { delay: 5000 }, 
                navigation: { nextEl: ".swiper-button-next", prevEl: ".swiper-button-prev" } 
            });
        }
    }

    // Regions
    const regionList = document.getElementById('region-list');
    if (regionList) {
        const allDistricts = regions.flatMap(r => r.districts).slice(0, 8);
        regionList.innerHTML = allDistricts.map(district => 
            `<a href="pages/region.html?district=${district.toLowerCase()}" class="px-6 py-3 bg-white border border-gray-200 rounded-full text-sm font-bold hover:bg-red-600 hover:text-white transition">${district}</a>`
        ).join('');
    }

    // Category grid
    const categoryGrid = document.getElementById('category-grid');
    if (categoryGrid) {
        categoryGrid.innerHTML = categories.map(cat => `
            <a href="../pages/regions/central.html" class="category-square bg-white border border-gray-100 rounded-[2rem] shadow-sm hover:shadow-2xl hover:border-red-500 hover:-translate-y-2 transition-all duration-500 group p-4">
                <div class="text-4xl mb-3 group-hover:scale-125 transition-transform duration-500 text-red-600">
                    <i class="fa-solid ${cat.icon}"></i>
                </div>
                <h3 class="font-black text-[10px] md:text-xs uppercase tracking-tight text-gray-800 text-center leading-tight group-hover:text-red-600">${cat.name}</h3>
            </a>
        `).join('');
    }

    // Featured businesses
    const featuredSection = document.getElementById('featured-businesses');
    if (featuredSection) {
        featuredSection.innerHTML = featuredBusinesses.map(business => `
            <a href="../pages/regions/central.html" class="bg-white rounded-2xl shadow-sm hover:shadow-xl transition-shadow overflow-hidden group block">
                <div class="relative h-48 overflow-hidden">
                    <img src="../pages/regions/central.html" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                    <div class="absolute top-3 right-3 bg-white px-2 py-1 rounded-full text-xs font-bold shadow-md">
                        ⭐ ${business.rating}
                    </div>
                </div>
                <div class="p-5">
                    <h3 class="font-black text-lg">${business.name}</h3>
                    <p class="text-gray-500 text-sm mt-1">${business.category}</p>
                    <div class="flex items-center gap-2 mt-3 text-sm text-gray-600">
                        <i class="fa-solid fa-location-dot text-red-600"></i> <span>${business.location}</span>
                    </div>
                </div>
            </a>
        `).join('');
    }
}

// NEW: Initialize Mobile Ad Carousel
function initializeMobileAdCarousel() {
    const track = document.getElementById('mobile-ad-track');
    if (!track) return;
    
    const ads = [
        { title: "Kampala Business Expo", date: "March 15-17, 2026", desc: "Business networking event" },
        { title: "Jinja Tourism Week", date: "April 5-12, 2026", desc: "Explore the source of the Nile" },
        { title: "Digital Marketing Workshop", date: "Every Saturday", desc: "Free training" },
        { title: "Stanbic Bank Uganda", date: "Business Loans", desc: "12% p.a. interest" },
        { title: "MTN Business", date: "Internet Solutions", desc: "Get connected today" }
    ];
    
    track.innerHTML = ads.map(ad => `
        <div class="mobile-ad-item">
            <div class="mobile-ad-title">${ad.title}</div>
            <div class="mobile-ad-date">${ad.date}</div>
            <div class="text-xs text-gray-600 mb-2">${ad.desc}</div>
            <a href="#" class="text-red-600 text-xs font-bold">Learn More →</a>
        </div>
    `).join('');
}

// NEW: Move to Top Button Functionality
function initializeMoveToTop() {
    const moveToTopBtn = document.getElementById('move-to-top');
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            moveToTopBtn.classList.add('visible');
        } else {
            moveToTopBtn.classList.remove('visible');
        }
    });
}

window.scrollToTop = function() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
};

// ==================== EVENT LISTENERS ====================
function attachEventListeners() {
    window.toggleMobileMenu = function() {
        const menu = document.getElementById('mobile-menu');
        if (menu) menu.classList.toggle('active');
    };

    window.toggleAccordion = function(btn) {
        if (btn) btn.parentElement.classList.toggle('accordion-active');
    };

    // Close panels when clicking outside
    document.addEventListener('click', function(event) {
        const mobileMenu = document.getElementById('mobile-menu');
        const menuBtn = document.querySelector('[onclick="toggleMobileMenu()"]');
        
        if (mobileMenu && mobileMenu.classList.contains('active') && 
            menuBtn && !mobileMenu.contains(event.target) && 
            !menuBtn.contains(event.target)) {
            toggleMobileMenu();
        }
    });
}