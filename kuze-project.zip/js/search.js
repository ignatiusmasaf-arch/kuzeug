// Search functionality
console.log('Search.js loaded');