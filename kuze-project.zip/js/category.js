// Category functionality
console.log('Category.js loaded');