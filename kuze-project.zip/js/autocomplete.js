// Autocomplete functionality
console.log('Autocomplete.js loaded');