// Featured Businesses Data
const featuredBusinesses = [
    { name: "Jinja Adventure Tours", category: "Entertainment & Tourism", location: "Jinja", rating: 4.8, image: "https://picsum.photos/seed/jinja1/400/300", slug: "jinja-adventure-tours" },
    { name: "Kampala City Hardware", category: "Construction", location: "Kampala", rating: 4.5, image: "https://picsum.photos/seed/hardware1/400/300", slug: "kampala-city-hardware" },
    { name: "Victoria Dental Clinic", category: "Health & Medical", location: "Kampala", rating: 4.9, image: "https://picsum.photos/seed/dental1/400/300", slug: "victoria-dental-clinic" },
    { name: "Mbarara Fresh Produce", category: "Agriculture", location: "Mbarara", rating: 4.7, image: "https://picsum.photos/seed/farm1/400/300", slug: "mbarara-fresh-produce" }
];

// Hero Slider Ads
const heroAds = [
    { name: "Kampala Business Expo 2026", image: "https://picsum.photos/seed/expo1/1600/600", link: "/events/business-expo" },
    { name: "Uganda Manufacturers Association", image: "https://picsum.photos/seed/uma1/1600/600", link: "/uma" },
    { name: "Jinja Tourism Week", image: "https://picsum.photos/seed/jinjatour/1600/600", link: "/tourism/jinja-week" },
    { name: "Kampala City Festival", image: "https://picsum.photos/seed/festival/1600/600", link: "/events/city-festival" }
];

// Regions Data
const regions = [
    { name: "Central", districts: ["Kampala", "Wakiso", "Mukono", "Masaka"] },
    { name: "Eastern", districts: ["Jinja", "Mbale", "Tororo", "Soroti"] },
    { name: "Northern", districts: ["Gulu", "Lira", "Arua", "Kitgum"] },
    { name: "Western", districts: ["Mbarara", "Kasese", "Fort Portal", "Kabale"] }
];