// Main page specific JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Swiper after components are loaded
    setTimeout(() => {
        initializeSwiper();
        loadHomePageContent();
    }, 200);
});

function initializeSwiper() {
    if (typeof Swiper !== 'undefined') {
        new Swiper(".mySwiper", { 
            loop: true, 
            autoplay: { delay: 5000 }, 
            navigation: { 
                nextEl: ".swiper-button-next", 
                prevEl: ".swiper-button-prev" 
            } 
        });
    }
}

function loadHomePageContent() {
    // Load hero slider
    const adWrapper = document.getElementById('ad-wrapper');
    if (adWrapper && typeof heroAds !== 'undefined') {
        adWrapper.innerHTML = heroAds.map(ad => `
            <div class="swiper-slide relative">
                <img src="../pages/regions/central.html" alt="${ad.name}" class="w-full h-full object-cover">
                <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent flex flex-col justify-end p-10 md:p-20 text-white">
                    <h2 class="text-4xl md:text-6xl font-black drop-shadow-2xl">${ad.name}</h2>
                </div>
            </div>
        `).join('');
    }

    // Load regions
    const regionList = document.getElementById('region-list');
    if (regionList && typeof regions !== 'undefined') {
        const allRegions = regions.flatMap(r => r.districts).slice(0, 8);
        regionList.innerHTML = allRegions.map(region => 
            `<a href="../pages/regions/central.html" class="px-6 py-3 bg-white border border-gray-200 rounded-full text-sm font-bold hover:bg-red-600 hover:text-white hover:border-red-600 transition">${region}</a>`
        ).join('');
    }

    // Load category grid
    const categoryGrid = document.getElementById('category-grid');
    if (categoryGrid && typeof categoryData !== 'undefined') {
        categoryGrid.innerHTML = categoryData.map(cat => {
            return `
                <a href="../pages/regions/central.html" class="category-square bg-white border border-gray-100 rounded-[2rem] shadow-sm hover:shadow-2xl hover:border-red-500 hover:-translate-y-2 transition-all duration-500 cursor-pointer group p-4">
                    <div class="text-4xl mb-3 group-hover:scale-125 transition-transform duration-500 text-red-600">
                        <i class="fa-solid ${cat.icon}"></i>
                    </div>
                    <h3 class="font-black text-[10px] md:text-xs uppercase tracking-tight text-gray-800 text-center leading-tight group-hover:text-red-600">${cat.name}</h3>
                </a>
            `;
        }).join('');
    }

    // Load featured businesses
    setTimeout(() => {
        const featuredSection = document.getElementById('featured-businesses');
        if (featuredSection && typeof featuredBusinesses !== 'undefined') {
            featuredSection.innerHTML = featuredBusinesses.map(business => `
                <a href="../pages/regions/central.html" class="bg-white rounded-2xl shadow-sm hover:shadow-xl transition-shadow overflow-hidden group block">
                    <div class="relative h-48 overflow-hidden">
                        <img src="../pages/regions/central.html" alt="${business.name}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                        <div class="absolute top-3 right-3 bg-white px-2 py-1 rounded-full text-xs font-bold shadow-md">
                            ⭐ ${business.rating}
                        </div>
                    </div>
                    <div class="p-5">
                        <h3 class="font-black text-lg">${business.name}</h3>
                        <p class="text-gray-500 text-sm mt-1">${business.category}</p>
                        <div class="flex items-center gap-2 mt-3 text-sm text-gray-600">
                            <i class="fa-solid fa-location-dot text-red-600"></i>
                            <span>${business.location}</span>
                        </div>
                    </div>
                </a>
            `).join('');
        }
    }, 1000);
}