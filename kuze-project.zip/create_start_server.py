#!/usr/bin/env python3
"""
Create start-server.bat for kuze.ug
Run this script to generate a working start-server.bat file
"""

import os

# Path to your project
PROJECT_PATH = r"C:\Users\Ignatius Masaf\Desktop\kuze-project"
BAT_FILE_PATH = os.path.join(PROJECT_PATH, "start-server.bat")

# Content of the start-server.bat file
BAT_CONTENT = '''@echo off
title kuze.ug Local Server
color 0A

:: Clear screen
cls

echo ╔══════════════════════════════════════════════════════════╗
echo ║           🚀 kuze.ug Local Server                        ║
echo ║           Uganda Business Directory                      ║
echo ╚══════════════════════════════════════════════════════════╝
echo.

:: Get current directory
set CURRENT_DIR=%CD%
echo 📂 Current folder: %CURRENT_DIR%
echo.

:: Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python is NOT installed!
    echo.
    echo ===== INSTALL PYTHON =====
    echo Download from: https://www.python.org/downloads/
    echo.
    echo ===== ALTERNATIVES =====
    echo Option 1: Just open index.html directly
    echo   start index.html
    echo.
    echo Option 2: Use PHP if installed
    echo   php -S localhost:8000
    echo.
    echo Option 3: Use Node.js if installed
    echo   npx http-server -p 8000
    echo.
    pause
    exit /b 1
)

:: Get Python version
for /f "tokens=*" %%i in ('python --version 2^>^&1') do set PY_VERSION=%%i
echo ✅ %PY_VERSION%

:: Get local IP address
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4 Address"') do set IP=%%a
set IP=%IP: =%

:: Remove any trailing spaces
set IP=%IP: =%

echo.
echo ═══════════════════════════════════════════════════════════
echo   🌐 SERVER INFORMATION
echo ═══════════════════════════════════════════════════════════
echo.
echo   • Local URL:  http://localhost:8000
if not "%IP%"=="" (
    echo   • Network URL: http://%IP%:8000
) else (
    echo   • Network URL: Unable to detect
)
echo.
echo   • Serving folder: %CURRENT_DIR%
echo   • Press Ctrl+C to stop the server
echo.
echo ═══════════════════════════════════════════════════════════
echo.

:: Test if port 8000 is available
netstat -ano | findstr :8000 >nul 2>&1
if not errorlevel 1 (
    echo ⚠️  Port 8000 is already in use!
    echo.
    echo ===== OPTIONS =====
    echo 1. Use different port
    echo 2. Close the program using port 8000
    echo.
    set /p USE_ALT="Use alternative port 8080? (y/n): "
    if /i "!USE_ALT!"=="y" (
        set PORT=8080
    ) else (
        echo.
        echo To find what's using port 8000:
        echo   netstat -ano ^| findstr :8000
        echo   taskkill /PID [number] /F
        echo.
        pause
        exit /b
    )
) else (
    set PORT=8000
)

:: Set port if not already set
if not defined PORT set PORT=8000

:: Open browser after a short delay
timeout /t 2 /nobreak >nul
start http://localhost:%PORT%

echo 🚀 Starting server on port %PORT%...
echo.
echo Press Ctrl+C to stop the server
echo.

:: Start the server
python -m http.server %PORT%

:: If server fails to start
if errorlevel 1 (
    echo.
    echo ❌ Failed to start server on port %PORT%!
    echo.
    echo ===== TRY THESE =====
    echo 1. Try a different port:
    echo      python -m http.server 8080
    echo.
    echo 2. Check if Python is working:
    echo      python --version
    echo.
    echo 3. Open index.html directly:
    echo      start index.html
    echo.
    pause
)

:: Keep window open if server stops
pause
'''

# Alternative simple version (if the above is too complex)
SIMPLE_BAT_CONTENT = '''@echo off
title kuze.ug Server
color 0A

echo ========================================
echo    🚀 kuze.ug Local Server
echo ========================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python not found!
    echo.
    echo Opening index.html directly...
    start index.html
    pause
    exit /b
)

echo ✅ Starting server...
echo.
echo 📁 Folder: %CD%
echo 🌐 URL: http://localhost:8000
echo.
echo Press Ctrl+C to stop
echo ========================================
echo.

:: Try port 8000, if busy try 8080
python -m http.server 8000 2>nul
if errorlevel 1 (
    echo ⚠️ Port 8000 busy, trying 8080...
    start http://localhost:8080
    python -m http.server 8080
) else (
    start http://localhost:8000
)

pause
'''

# Ultra simple version
ULTRA_SIMPLE_BAT = '''@echo off
echo Starting kuze.ug server...
python -m http.server 8000
pause
'''

def create_bat_file():
    """Create the start-server.bat file"""
    
    print("=" * 60)
    print("  🔧 Creating start-server.bat for kuze.ug")
    print("=" * 60)
    print()
    
    # Check if project folder exists
    if not os.path.exists(PROJECT_PATH):
        print(f"❌ Error: Project folder not found!")
        print(f"   Looking for: {PROJECT_PATH}")
        print()
        print("Please update the PROJECT_PATH in this script.")
        return False
    
    print(f"📁 Project folder: {PROJECT_PATH}")
    print()
    
    # Ask which version to create
    print("Choose a version:")
    print("1. Full featured (recommended) - with error handling and network detection")
    print("2. Simple version - clean and straightforward")
    print("3. Ultra simple - just the basics")
    print()
    
    choice = input("Enter choice (1, 2, or 3): ").strip()
    
    if choice == "1":
        content = BAT_CONTENT
        desc = "full featured"
    elif choice == "2":
        content = SIMPLE_BAT_CONTENT
        desc = "simple"
    elif choice == "3":
        content = ULTRA_SIMPLE_BAT
        desc = "ultra simple"
    else:
        print("❌ Invalid choice. Using full featured version.")
        content = BAT_CONTENT
        desc = "full featured"
    
    # Create the file
    try:
        with open(BAT_FILE_PATH, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print(f"\n✅ {desc} start-server.bat created successfully!")
        print(f"   Location: {BAT_FILE_PATH}")
        print()
        print("🚀 To use:")
        print("   1. Navigate to your project folder")
        print("   2. Double-click start-server.bat")
        print("   3. Your browser will open to http://localhost:8000")
        print()
        
        # Ask if they want to test it now
        test_now = input("Do you want to test it now? (y/n): ").strip().lower()
        if test_now == 'y':
            os.chdir(PROJECT_PATH)
            os.system('start start-server.bat')
            print("✅ Server starting... Check the new window.")
        
        return True
        
    except Exception as e:
        print(f"❌ Error creating file: {e}")
        return False

def create_all_versions():
    """Create all three versions with different names"""
    
    versions = [
        ("start-server-full.bat", BAT_CONTENT, "Full featured"),
        ("start-server.bat", SIMPLE_BAT_CONTENT, "Simple (default)"),
        ("start-server-min.bat", ULTRA_SIMPLE_BAT, "Minimal")
    ]
    
    print("=" * 60)
    print("  🔧 Creating all server batch files")
    print("=" * 60)
    print()
    
    if not os.path.exists(PROJECT_PATH):
        print(f"❌ Error: Project folder not found!")
        return False
    
    created = 0
    for filename, content, desc in versions:
        filepath = os.path.join(PROJECT_PATH, filename)
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"✅ Created: {filename} ({desc})")
            created += 1
        except Exception as e:
            print(f"❌ Failed to create {filename}: {e}")
    
    print(f"\n📁 {created} files created in: {PROJECT_PATH}")
    print()
    print("🚀 Recommended: Use start-server.bat (simple version)")
    
    return True

if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("  🔧 start-server.bat Generator for kuze.ug")
    print("=" * 60)
    print()
    
    # Ask what to create
    print("Options:")
    print("1. Create a single batch file (choose version)")
    print("2. Create all three versions")
    print()
    
    option = input("Enter choice (1 or 2): ").strip()
    
    if option == "2":
        create_all_versions()
    else:
        create_bat_file()
    
    print("\n" + "=" * 60)
    input("Press Enter to exit...")