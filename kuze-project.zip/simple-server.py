#!/usr/bin/env python3
"""
Simple HTTP Server for kuze.ug
Just run this file and open http://localhost:8000
"""

import http.server
import socketserver
import webbrowser
import os

PORT = 8000
DIRECTORY = r"C:\Users\Ignatius Masaf\Desktop\kuze-project"

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

print("=" * 50)
print("  🚀 kuze.ug Server Starting...")
print("=" * 50)
print(f"\n📁 Serving: {DIRECTORY}")
print(f"🌐 Open: http://localhost:{PORT}")
print("\nPress Ctrl+C to stop\n")

# Open browser
webbrowser.open(f'http://localhost:{PORT}')

# Start server
with socketserver.TCPServer(("", PORT), Handler) as httpd:
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n\n✅ Server stopped.")