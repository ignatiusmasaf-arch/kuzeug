#!/usr/bin/env python3
"""
kuze.ug Local Development Server
Run this script to start a local server with hot reload and debugging features
"""

import os
import sys
import webbrowser
import socket
import json
from http.server import HTTPServer, SimpleHTTPRequestHandler
from datetime import datetime
import time

# ==================== CONFIGURATION ====================
DEFAULT_PORT = 8000
BACKUP_PORT = 8080
PROJECT_PATH = os.path.dirname(os.path.abspath(__file__))
LOG_FILE = os.path.join(PROJECT_PATH, 'server_log.txt')

# ==================== COLOR CODES FOR TERMINAL ====================
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

# ==================== CUSTOM HANDLER WITH DEBUGGING ====================
class KuzeHTTPRequestHandler(SimpleHTTPRequestHandler):
    """Custom request handler with logging and debugging features"""
    
    def log_message(self, format, *args):
        """Override log_message to add timestamps and colors"""
        timestamp = datetime.now().strftime('%H:%M:%S')
        message = format % args
        
        # Color-code based on status code
        if args[1].startswith('200'):
            status_color = Colors.GREEN
        elif args[1].startswith('30'):
            status_color = Colors.BLUE
        elif args[1].startswith('40'):
            status_color = Colors.YELLOW
        else:
            status_color = Colors.RED
        
        print(f"{Colors.BOLD}{timestamp}{Colors.END} | "
              f"{status_color}{args[1]}{Colors.END} | "
              f"{args[0]} {args[2]}")
        
        # Also log to file
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(f"{datetime.now()} | {args[1]} | {args[0]} {args[2]}\n")
    
    def do_GET(self):
        """Handle GET requests with special handling for certain files"""
        
        # Handle clean URLs (serve .html without extension)
        if not os.path.exists(self.translate_path(self.path)):
            # Check if it's a file without .html extension
            html_path = self.path
            if not html_path.endswith('.html') and '.' not in html_path.split('/')[-1]:
                test_path = self.translate_path(html_path + '.html')
                if os.path.exists(test_path):
                    self.path = html_path + '.html'
        
        # Check if it's a directory, serve index.html
        full_path = self.translate_path(self.path)
        if os.path.isdir(full_path):
            index_path = os.path.join(full_path, 'index.html')
            if os.path.exists(index_path):
                self.path = os.path.join(self.path, 'index.html')
        
        # Call parent method
        try:
            super().do_GET()
        except Exception as e:
            self.send_error(500, f"Server error: {str(e)}")
    
    def end_headers(self):
        """Add CORS headers to allow development"""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        super().end_headers()

# ==================== SERVER FUNCTIONS ====================

def find_available_port(start_port):
    """Find an available port starting from start_port"""
    port = start_port
    while port < start_port + 100:
        try:
            test_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            test_socket.bind(('', port))
            test_socket.close()
            return port
        except OSError:
            port += 1
    return None

def get_local_ip():
    """Get local IP address for network access"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return '127.0.0.1'

def create_info_json():
    """Create a info.json file with project information"""
    info = {
        'project': 'kuze.ug',
        'description': 'Uganda Business Directory',
        'pages': [
            'index.html',
            'about.html',
            'contact.html',
            'blog.html',
            '404.html'
        ],
        'components': ['header', 'footer', 'mobile-menu', 'emergency-contacts'],
        'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    with open(os.path.join(PROJECT_PATH, 'info.json'), 'w') as f:
        json.dump(info, f, indent=2)

# ==================== MAIN SERVER FUNCTION ====================

def run_server(port=None, open_browser=True):
    """Main server function"""
    
    # Clear screen
    os.system('cls' if os.name == 'nt' else 'clear')
    
    # Print banner
    print(f"{Colors.RED}{Colors.BOLD}")
    print("╔════════════════════════════════════════════════════════════╗")
    print("║                    🚀 kuze.ug Server                       ║")
    print("║                    Uganda Business Directory               ║")
    print("╚════════════════════════════════════════════════════════════╝")
    print(f"{Colors.END}")
    
    # Check if running in correct directory
    if not os.path.exists(os.path.join(PROJECT_PATH, 'index.html')):
        print(f"{Colors.RED}❌ Error: index.html not found!{Colors.END}")
        print(f"Current directory: {PROJECT_PATH}")
        print("Please run this script from your kuze.ug project root.")
        return
    
    # Find available port
    if port is None:
        port = find_available_port(DEFAULT_PORT)
        if port is None:
            print(f"{Colors.YELLOW}⚠️ Port {DEFAULT_PORT} and nearby ports are busy.{Colors.END}")
            print(f"{Colors.YELLOW}Trying to find any available port...{Colors.END}")
            port = find_available_port(3000)
    
    if port is None:
        print(f"{Colors.RED}❌ No available ports found!{Colors.END}")
        return
    
    # Get local IP
    local_ip = get_local_ip()
    
    # Create info.json
    create_info_json()
    
    # Server information
    print(f"\n{Colors.BOLD}📁 Project:{Colors.END} {PROJECT_PATH}")
    print(f"\n{Colors.GREEN}✅ Server is running!{Colors.END}\n")
    
    print(f"{Colors.BOLD}🌐 Local URLs:{Colors.END}")
    print(f"   • Main:     {Colors.UNDERLINE}http://localhost:{port}{Colors.END}")
    print(f"   • Network:  {Colors.UNDERLINE}http://{local_ip}:{port}{Colors.END}")
    print()
    
    print(f"{Colors.BOLD}📄 Key Pages:{Colors.END}")
    pages = [
        ('Home', '/'),
        ('About', '/about.html'),
        ('Contact', '/contact.html'),
        ('Blog', '/blog.html'),
        ('Categories', '/pages/category/index.html'),
        ('Regions', '/pages/regions/regions.html'),
        ('Add Business', '/pages/business/add.html'),
        ('Login', '/pages/user/login.html'),
        ('Register', '/pages/user/register.html'),
        ('Help', '/help/faq.html')
    ]
    
    for name, url in pages:
        full_url = f"http://localhost:{port}{url}"
        print(f"   • {name}: {Colors.UNDERLINE}{full_url}{Colors.END}")
    
    print(f"\n{Colors.BOLD}🔧 Features:{Colors.END}")
    print(f"   • Live logging with timestamps")
    print(f"   • Clean URLs (no .html extension needed)")
    print(f"   • Auto-directory to index.html")
    print(f"   • CORS headers enabled")
    print(f"   • Logs saved to: {LOG_FILE}")
    
    print(f"\n{Colors.YELLOW}⚠️  Press Ctrl+C to stop the server{Colors.END}\n")
    print("─" * 60)
    
    # Open browser automatically
    if open_browser:
        webbrowser.open(f'http://localhost:{port}')
    
    # Start server
    server_address = ('', port)
    httpd = HTTPServer(server_address, KuzeHTTPRequestHandler)
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.GREEN}✅ Server stopped.{Colors.END}")
        print(f"Log file saved to: {LOG_FILE}")
    finally:
        httpd.server_close()

# ==================== COMMAND LINE INTERFACE ====================

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='kuze.ug Local Development Server')
    parser.add_argument('-p', '--port', type=int, default=None, 
                       help='Port to run the server on (default: auto-detect)')
    parser.add_argument('-nb', '--no-browser', action='store_true',
                       help="Don't open browser automatically")
    parser.add_argument('--log', action='store_true',
                       help='View the server log')
    
    args = parser.parse_args()
    
    if args.log:
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, 'r') as f:
                print(f.read())
        else:
            print("No log file found yet.")
        sys.exit(0)
    
    # Run server
    run_server(port=args.port, open_browser=not args.no_browser)